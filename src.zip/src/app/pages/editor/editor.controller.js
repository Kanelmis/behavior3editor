angular
  .module('app')
  .controller('EditorController', EditorController);

EditorController.$inject = [];

function EditorController() {
  
}