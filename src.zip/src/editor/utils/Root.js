/**
 * Root node specification.
 */
b3e.Root = {
  name     : 'Root',
  category : 'root',
  title    : 'A behavior tree'
};