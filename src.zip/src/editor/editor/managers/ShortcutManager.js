b3e.editor.ShortcutManager = function(editor) {
  "use strict";

  this._applySettings = function(settings) {};
};