b3e.editor.CollapseSystem = function(editor) {
  "use strict";

  this.update = function(delta) {

  };
};
