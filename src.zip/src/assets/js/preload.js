function preloadProgress(message) {
  var element = document.getElementById('page-preload-progress');
  element.innerHTML = message;
}